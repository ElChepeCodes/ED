/*
 * Estructuras de datos
 * Autores: 
    Jose Luis Gutierrez Espinosa
    Andrés Navarrete
    Andrés Quevedo
    Bruno Vitte San Juan
    
 */
package proyectocalculadora;

/**
 *
 * @author jlgut
 */
public interface Caracter {
    
}
