/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenfinalsolucion;

/**
 *
 * @author ZVIX0
 */
public class ListaDesordenada<T> {
    private LinearNode<T> primero;
    
    public ListaDesordenada() {
        primero=null;
    }

    public LinearNode<T> getPrimero() {
        return primero;
    }
    
    public void addToFront(T dato) {
        LinearNode<T> nuevo=new LinearNode(dato);
        nuevo.setSiguiente(primero);
        primero=nuevo;
    }

    public String toString() {
        StringBuilder sb=new StringBuilder("");
        LinearNode<T> aux=primero;
        if(aux!=null) {
            while(aux.getSiguiente()!=null) {
                sb.append(aux.getDato()+", ");
                aux=aux.getSiguiente();
            }
            sb.append(aux.getDato()+"\n");
        }
        else
            sb.append("\n");
        
        return sb.toString();
    }
}
