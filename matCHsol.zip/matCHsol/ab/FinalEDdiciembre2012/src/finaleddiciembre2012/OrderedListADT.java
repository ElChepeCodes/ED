package finaleddiciembre2012;

public interface OrderedListADT<T> extends ListADT<T> {
    public void add (T dato);
}
