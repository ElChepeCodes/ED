/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package finaleddiciembre2012;

/**
 *
 * @author AGOMEZDG
 */
import java.util.*;

public class ListaDoblementeEnlazada<T> implements ListADT<T> {
    protected DoublyLinkedNode<T> primero,último;
    
    public ListaDoblementeEnlazada() {
        primero=último=null;
    }
    
    public Iterator<T> iterator() {
        return new DoublyLinkedIterator(último);
    }
    
    public void clear() {
        
    }

}
