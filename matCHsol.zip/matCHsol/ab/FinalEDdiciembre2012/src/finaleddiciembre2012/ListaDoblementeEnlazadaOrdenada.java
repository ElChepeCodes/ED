/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package finaleddiciembre2012;

/**
 *
 * @author AGOMEZDG
 */
public class ListaDoblementeEnlazadaOrdenada<T> extends ListaDoblementeEnlazada<T> implements OrderedListADT<T> {
    
}
