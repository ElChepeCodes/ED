package Problemas00DblLists;
import DoubleLists.*;

/**
 * Problemas usando Double Linked Lists
 * @author EDg1
 */
public class Problemas00DblListsMain {

    public static void main(String[] args) {
        DoublyLinkedOrderedList<Integer> lista = new DoublyLinkedOrderedList<>();
        lista.add(1);
        lista.add(30);
        lista.add(-2);
        lista.add(4);
        System.out.println(lista);     
    }        
    
}
